## NextJS UserRestAPI

# build
```
docker-compose up --build
```

# swagger
```
http://localhost:3000/api
```

# demo
```
http://142.93.234.118:8000/docs
```

# video demo
```
https://www.loom.com/share/c30733db82d94e7ebaa247d6feec9f87
```