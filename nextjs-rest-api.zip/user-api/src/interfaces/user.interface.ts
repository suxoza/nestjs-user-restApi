
export class UserInterface {
    name: string;
    email: string;
    avatar: string;
    avatarHash: string;
}